package com.mousebackpro

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnActivar: Button = findViewById(R.id.btnActivar)
        val tvEstado: TextView = findViewById(R.id.tvEstado)

        btnActivar.setOnClickListener {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            startActivity(intent)
        }
    }

    override fun onResume() {
        super.onResume()
        val tvEstado: TextView = findViewById(R.id.tvEstado)
        tvEstado.text = "Ve a Ajustes → Accesibilidad → MouseBackPro → Activar"
    }
}